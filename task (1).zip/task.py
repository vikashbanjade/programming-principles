class Ticket:
    counter = 1
    tickets = []
    tickets_created = 0
    tickets_resolved = 0
    tickets_open = 0

    def __init__(self, ticket_creator_name, staff_id, email, description):
        self.ticket_number = Ticket.counter + 2000
        Ticket.counter += 1
        self.ticket_creator_name = ticket_creator_name
        self.staff_id = staff_id
        self.email = email
        self.description = description
        self.response = "Not Yet Provided"
        self.status = "Open"
        Ticket.tickets.append(self)
        Ticket.tickets_created += 1
        Ticket.tickets_open += 1

    def resolve_ticket(self, response):
        if self.status == "Open":
            self.response = response
            self.status = "Closed"
            Ticket.tickets_resolved += 1
            Ticket.tickets_open -= 1
        else:
            print(f"Cannot resolve ticket {self.ticket_number} as it is not in the Open status.")

    def reopen_ticket(self):
        self.status = "Reopened"
        Ticket.tickets_resolved -= 1
        Ticket.tickets_open += 1

    def resolve_password_change(self):
        new_password = self.staff_id[:2] + self.ticket_creator_name[:3]
        self.response = "New password generated: " + new_password
        self.status = "Closed"
        Ticket.tickets_resolved += 1
        Ticket.tickets_open -= 1

    @staticmethod
    def print_ticket_stats():
        print("Displaying Ticket Statistics")
        print("Tickets Created:", Ticket.tickets_created)
        print("Tickets Resolved:", Ticket.tickets_resolved)
        print("Tickets To Solve:", Ticket.tickets_open)
        print()

    @staticmethod
    def print_tickets():
        print("Printing Tickets:")
        for ticket in Ticket.tickets:
            print("Ticket Number:", ticket.ticket_number)
            print("Ticket Creator:", ticket.ticket_creator_name)
            print("Staff ID:", ticket.staff_id)
            print("Email Address:", ticket.email)
            print("Description:", ticket.description)
            print("Response:", ticket.response)
            print("Ticket Status:", ticket.status)
            print()

def main():

    # Create tickets and manage their life cycle
    ticket_creator_name = input("Enter the ticket creator's name: ")
    staff_id = input("Enter the staff ID: ")
    email = input("Enter the email address: ")
    description = input("Enter the description of the issue: ")
    ticket1 = Ticket(ticket_creator_name, staff_id, email, description)

    ticket_creator_name = input("Enter the ticket creator's name: ")
    staff_id = input("Enter the staff ID: ")
    email = input("Enter the email address: ")
    description = input("Enter the description of the issue: ")
    ticket2 = Ticket(ticket_creator_name, staff_id, email, description)

    ticket_creator_name = input("Enter the ticket creator's name: ")
    staff_id = input("Enter the staff ID: ")
    email = input("Enter the email address: ")
    description = input("Enter the description of the issue: ")
    ticket3 = Ticket(ticket_creator_name, staff_id, email, description)

    Ticket.print_ticket_stats()
    Ticket.print_tickets()

    response = input("Enter the response for ticket 3: ")
    ticket3.resolve_password_change()

    Ticket.print_ticket_stats()
    Ticket.print_tickets()

    response = input("Enter the response for ticket 1: ")
    ticket1.resolve_ticket(response)
    ticket2.reopen_ticket()
    response = input("Enter the response for ticket 2: ")
    ticket2.resolve_ticket(response)

    Ticket.print_ticket_stats()
    Ticket.print_tickets()


if __name__ == "__main__":
    main()